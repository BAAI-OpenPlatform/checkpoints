---
license: [mit](https://model.baai.ac.cn/use-agreement)
---

# GPT2

## 简介/Overview

The GPT2 model was proposed in [Language Models are Unsupervised Multitask Learners](https://d4mucfpksywv.cloudfront.net/better-language-models/language-models.pdf)
by Alec Radford, Jeffrey Wu, Rewon Child, David Luan, Dario Amodei, Ilya Sutskever

## 训练数据/Training data

[CLUECorpus2020](https://github.com/CLUEbenchmark/CLUECorpus2020/).


## 使用方式/How to use

### 推断/inference

[GPT2模型](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_15_GPT2_WRITING.md)可用于文本生成

One can use [GPT2 model](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_15_GPT2_WRITING.md) to write text by giving it a beginning.

## Source

原代码可以点击此处[here](https://github.com/openai/gpt-2).

The original code can be found [here](https://github.com/openai/gpt-2).

