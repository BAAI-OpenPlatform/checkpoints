---
license: [apache2.0](https://model.baai.ac.cn/use-agreement)
---

# BERT

## 简介/Overview

The BERT model was proposed in [BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding](https://arxiv.org/abs/1810.04805)
by Jacob Devlin, Ming-Wei Chang, Kenton Lee, Kristina Toutanova


## 训练数据/Training data

英文版维基百科和BooksCropus

English Wikipedia and BooksCropus.

## 使用方式/How to use

### 微调与推断/Finetune and inference

BERT 模型可用于[分类](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_16_BERT_EXAMPLE_SEMANTIC_MATCHING.md)，[序列标注](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_17_BERT_EXAMPLE_NER.md)和[序列生成](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_15_BERT_EXAMPLE_TITLE_GENERATION.md)任务

One can use BERT model to do [classification](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_16_BERT_EXAMPLE_SEMANTIC_MATCHING.md), [sequence labeling](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_17_BERT_EXAMPLE_NER.md) and [seq2seq](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_15_BERT_EXAMPLE_TITLE_GENERATION.md) tasks.


## 来源/Source

原代码可以点击此处[here](https://github.com/google-research/bert).

The original code can be found [here](https://github.com/google-research/bert).

