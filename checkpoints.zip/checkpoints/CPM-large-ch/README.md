---
license: [悟道开源协议](https://model.baai.ac.cn/use-agreement)
---

# CPM-large-ch

## 简介/Overview
中文预训练语言模型（CPM）是基于transformers 的自回归语言模型，其训练使用了100G中文数据，最大版本包含26亿参数，支持包括文本分类获取CPM文章[了解更多](https://arxiv.org/abs/2012.00413)


CPM (Chinese Pre-trained Language Model) is a Transformer-based autoregressive language model, with 2.6 billion parameters and 100GB Chinese training data.  The paper is available at [here](https://arxiv.org/abs/2012.00413)


## 训练数据集/Training data

CPM 训练共使用了，100G 数据，包括百科全书，网页数据，新闻数据，小说数据，故事和对话。
CPM  model was  pretrained on Encyclopedia, Webpage, News, story，Dialog


|  Data Source| Encyclopedia | Webpage | story| News | Dialog |
|  ----  | ---- | ---- | ---- | ---- | ---- | 
| Size  | 40 GB | 39 GB | 10 GB | 10 GB |10GB| 1GB | 

## 任务/How to use
CPM 可以用于[文本分类](https://github.com/TsinghuaAI/CPM-1-Generate/blob/main/scripts/zero-shot-tnews.sh)和
[文本生成](https://github.com/TsinghuaAI/CPM-1-Generate/blob/main/scripts/generate_text.sh)

GLM can be used to do  [text classification](https://github.com/TsinghuaAI/CPM-1-Generate/blob/main/scripts/zero-shot-tnews.sh)和
[text generation](https://github.com/TsinghuaAI/CPM-1-Generate/blob/main/scripts/generate_text.sh)
 


## Quick start
基于[transformers](https://github.com/huggingface/transformers)，用户可以使用CPM 生成文本

With [transformers](https://github.com/huggingface/transformers)，one can use CPM to generate texts
### Inference
```python
from transformers import TextGenerationPipeline, AutoTokenizer, AutoModelWithLMHead
tokenizer = AutoTokenizer.from_pretrained("TsinghuaAI/CPM-Generate")
model = AutoModelWithLMHead.from_pretrained("TsinghuaAI/CPM-Generate")

text_generator = TextGenerationPipeline(model, tokenizer)
text_generator('清华大学', max_length=50, do_sample=True, top_p=0.9)
```
## 来源/Source
CPM的源代码来源于[此处](https://github.com/TsinghuaAI/CPM-1-Generate)

The original code of CPM is available at [here](https://github.com/TsinghuaAI/CPM-1-Generate).

 