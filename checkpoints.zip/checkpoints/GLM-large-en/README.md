
---
license: [mit](https://model.baai.ac.cn/use-agreement)
---

# GLM

## 简介/Overview
GLM 模型是基于自回归填空的通用语言预训练模型，包含中文和英文两种语言版本，同时包含多个不同规模的版本。该版本是GLM-335M 英文版。更多版本信息可见论文 [GLM: General Language Model Pretraining with Autoregressive Blank Infilling](https://arxiv.org/abs/2103.10360)。模型源码可见 [here](https://github.com/THUDM/GLM)

The General Language Model (GLM) is a laguage model based on autoregressive blank infilling which contains Chinese and English laguage versions and different sizes of versions. The version of this model is English laguage with 335M parameters. For more information can click the  paper link  [GLM: General Language Model Pretraining with Autoregressive Blank Infilling](https://arxiv.org/abs/2103.10360) and the origin [code link](https://github.com/THUDM/GLM).
  


## 训练数据集/Training data 
GLM 英文 large 模型 训练使用了 Wikipedia，Bookcorpus, cc-news 数据
The English GLM model was  pretrained on  Wikipedia，Bookcorpus, cc-news.

 

## 使用方式/How to use

### 微调/Finetune

依托于[FlagAI](https://gitee.com/link?target=https%3A%2F%2Fgithub.com%2FBAAI-Open%2FFlagAI), GLM 英文large版 可以用于英文生成式问答任务

With [FlagAI](https://gitee.com/link?target=https%3A%2F%2Fgithub.com%2FBAAI-Open%2FFlagAI), one can use GLM large model directly  for QA by using graph generation task


### 快速使用/Quick start

```python
import torch
from flagai.model.glm_model import GLMModel
from flagai.data.tokenizer import GLMLargeChTokenizer
from flagai.model.predictor.predictor import Predictor
if __name__ == "__main__":
    tokenizer = GLMLargeChTokenizer(vocab_path='./checkpoints/glm-large-en/cog-pretrain.model',
                                    add_block_symbols=True, add_task_mask=True, add_decoder_mask=False,
                                    fix_command_token=False)
    model = GLMModel.from_pretrain(model_name='glm-large-en', only_download_config=False)
    model.cuda(torch.cuda.current_device())
    predictor = Predictor(model, tokenizer)
    text = 'Ng is an adjunct professor at [MASK] (formerly associate professor and Director of its Stanford AI Lab or SAIL ). Also a pioneer in online education, Ng co-founded Coursera and deeplearning.ai.'
    output=predictor.predict_generate_randomsample(text)
    print(text,'\n',output)
```
类似于Bert, 用户可以用GLM 预测单词

Similar to BERT, GLM can predict masked tokens as 

```python
import torch
from flagai.model.glm_model import GLMModel
from flagai.data.tokenizer import GLMLargeChTokenizer
from flagai.model.predictor.predictor import Predictor
if __name__ == "__main__":
    tokenizer = GLMLargeChTokenizer(vocab_path='./checkpoints/glm-large-en/cog-pretrain.model',
                                    add_block_symbols=True, add_task_mask=True, add_decoder_mask=False,
                                    fix_command_token=False)
    model = GLMModel.from_pretrain(model_name='glm-large-en', only_download_config=False)
    model.cuda(torch.cuda.current_device())
    predictor = Predictor(model, tokenizer)
    text = 'Ng is an adjunct professor at [MASK] (formerly associate professor and Director of its Stanford AI Lab or SAIL ). Also a pioneer in online education, Ng co-founded Coursera and deeplearning.ai.'
    output=predictor.predict_generate_randomsample(text)
    print(text,'\n',output)
```

GLM 也可以预测句子

and predict masked sentences as 

```python
import torch
from flagai.model.glm_model import GLMModel
from flagai.data.tokenizer import GLMLargeChTokenizer
from flagai.model.predictor.predictor import Predictor
if __name__ == "__main__":
    tokenizer = GLMLargeChTokenizer(vocab_path='./checkpoints/glm-large-en/cog-pretrain.model',
                                    add_block_symbols=True, add_task_mask=True, add_decoder_mask=False,
                                    fix_command_token=False)
    model = GLMModel.from_pretrain(model_name='glm-large-en', only_download_config=False)
    model.cuda(torch.cuda.current_device())
    predictor = Predictor(model, tokenizer)
    text = 'There have been various types of pretraining architectures including autoencoding models (e.g., BERT), autoregressive models (e.g., GPT), and encoder-decoder models (e.g., T5). [sMASK] We propose a General Language Model (GLM) based on autoregressive blank infilling to address this challenge. GLM improves blank filling pretraining by adding 2D positional encodings and allowing an arbitrary order to predict spans, which results in performance gains over BERT and T5 on NLU tasks. Meanwhile, GLM can be pretrained for different types of tasks by varying the number and lengths of blanks. On a wide range of tasks across NLU, conditional and unconditional generation, GLM outperforms BERT, T5, and GPT given the same model sizes and data, and achieves the best performance from a single pretrained model with 1.25× parameters of BERT Large , demonstrating its generalizability to different downstream tasks.'
    output=predictor.predict_generate_randomsample(text)
```

 ## 来源/Source

原代码可以点击此处[here](https://github.com/THUDM/GLM).

The original code can be found [here](https://github.com/THUDM/GLM).
 

