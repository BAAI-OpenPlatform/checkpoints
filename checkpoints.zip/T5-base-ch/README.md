---
license: [mit](https://model.baai.ac.cn/use-agreement)
---

# T5

## 简介/Overview

The T5 model was proposed in [Exploring the Limits of Transfer Learning with a Unified Text-to-Text Transformer](https://arxiv.org/abs/1910.10683)
by Colin Raffel, Noam Shazeer, Adam Roberts, Katherine Lee, Sharan Narang, Michael Matena, Yanqi Zhou, Wei Li, Peter J. Liu

## 训练数据集/Training data 

[Pegasus](https://github.com/ZhuiyiTechnology/t5-pegasus).


### 微调和推断/Finetuned and inference

T5 模型可用于序列生成任务，例如[标题生成](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_19_T5_EXAMPLE_TITLE_GENERATION.md)。

One can use T5 model to do seq2seq task, for example [title-generation](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_19_T5_EXAMPLE_TITLE_GENERATION.md).

## Source

原代码可以点击此处[here](https://github.com/google-research/text-to-text-transfer-transformer).

The original code can be found [here](https://github.com/google-research/text-to-text-transfer-transformer).

