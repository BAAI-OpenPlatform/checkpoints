---
license: [mit](https://model.baai.ac.cn/use-agreement)
---

# GLM

## 简介/Overview
GLM 模型是基于自回归填空的通用语言预训练模型，包含中文和英文两种语言版本，同时包含多个不同规模的版本。该版本是GLM 335M 中文版。更多版本信息可见论文 [GLM: General Language Model Pretraining with Autoregressive Blank Infilling](https://arxiv.org/abs/2103.10360)。模型源码可见 [here](https://github.com/THUDM/GLM)

The General Language Model (GLM) is a laguage model based on autoregressive blank infilling which contains Chinese and English laguage versions and different sizes of versions. The version of this model is English laguage with 335M parameters. For more information can click the  paper link  [GLM: General Language Model Pretraining with Autoregressive Blank Infilling](https://arxiv.org/abs/2103.10360) and the origin [code link](https://github.com/THUDM/GLM).

  


## 训练数据集/Training data
GLM 中文large 模型训练使用了
The Chinese GLM model was  pretrained on [Wudaocorpora](http://120.92.111.73/details/WuDaoCorpora%20Text%20%E6%96%87%E6%9C%AC%E9%A2%84%E8%AE%AD%E7%BB%83%E6%95%B0%E6%8D%AE%E9%9B%86), Zhihu, Zhidao, Baidubaike

 

## 使用方式/How to use

### 预训练PreTrain

基于[FlagAI](https://gitee.com/link?target=https%3A%2F%2Fgithub.com%2FBAAI-Open%2FFlagAI)，用户可以使用领域数据在GLM模型上[继续训练](https://github.com/BAAI-Open/FlagAI/tree/master/examples/glm_pretrain)

With [FlagAI](https://gitee.com/link?target=https%3A%2F%2Fgithub.com%2FBAAI-Open%2FFlagAI), one can continue [training GLM](https://github.com/BAAI-Open/FlagAI/tree/master/examples/glm_pretrain)
 model with the domain data



### 快速使用/Quick start
基于[FlagAI](https://gitee.com/link?target=https%3A%2F%2Fgithub.com%2FBAAI-Open%2FFlagAI), GLM 可以用于中文生成式问答任务

With [FlagAI](https://gitee.com/link?target=https%3A%2F%2Fgithub.com%2FBAAI-Open%2FFlagAI), one can use GLM model directly  for QA by using graph generation task:

```python
import torch
from flagai.model.glm_model import GLMModel
from flagai.data.tokenizer import GLMLargeChTokenizer
from flagai.model.predictor.predictor import Predictor
if __name__ == "__main__":
    tokenizer = GLMLargeChTokenizer(vocab_path='./checkpoints/glm-large-ch/cog-pretrain.model',
                                    add_block_symbols=True, add_task_mask=True, add_decoder_mask=False,
                                    fix_command_token=False)
    model = GLMModel.from_pretrain(model_name='glm-large-ch', only_download_config=False)
    model.cuda(torch.cuda.current_device())
    predictor = Predictor(model, tokenizer)
    text = '问题：啤酒伤胃吗？回答：[gMASK]'
    output=predictor.predict_generate_randomsample(text)
    print(text,'\n',output)
```
类似于Bert, 用户可以用GLM 预测单词

Similar to BERT, GLM can predict masked tokens as 

```python
import torch
from flagai.model.glm_model import GLMModel
from flagai.data.tokenizer import GLMLargeChTokenizer
from flagai.model.predictor.predictor import Predictor
if __name__ == "__main__":
    tokenizer = GLMLargeChTokenizer(vocab_path='./checkpoints/glm-large-ch/cog-pretrain.model',
                                    add_block_symbols=True, add_task_mask=True, add_decoder_mask=False,
                                    fix_command_token=False)
    model = GLMModel.from_pretrain(model_name='glm-large-ch', only_download_config=False)
    model.cuda(torch.cuda.current_device())
    predictor = Predictor(model, tokenizer)
    text = '北京故宫是中国[MASK]非物质文化遗产。'
    output=predictor.predict_generate_randomsample(text)
    print(text,'\n',output)
```

GLM 也可以预测句子

and predict masked sentences as 

```python
import torch
from flagai.model.glm_model import GLMModel
from flagai.data.tokenizer import GLMLargeChTokenizer
from flagai.model.predictor.predictor import Predictor
if __name__ == "__main__":
    tokenizer = GLMLargeChTokenizer(vocab_path='./checkpoints/glm-large-ch/cog-pretrain.model',
                                    add_block_symbols=True, add_task_mask=True, add_decoder_mask=False,
                                    fix_command_token=False)
    model = GLMModel.from_pretrain(model_name='glm-large-ch', only_download_config=False)
    model.cuda(torch.cuda.current_device())
    predictor = Predictor(model, tokenizer)
    text = '人工智能是一个以计算机科学为基础，由计算机、数学、哲学等多学科交叉融合的交叉学科，[sMASK]，具有非常巨大的前景。'
    output=predictor.predict_generate_randomsample(text)
```

 
