---
license: [apache2.0](https://model.baai.ac.cn/use-agreement)
---

# RoBERTa-base-ch Chinese

## 简介/Overview

RoBERTa-base-ch 模型使用了哈工大讯飞联合实验室（HFL）开源的 RoBERTa-wwm-ext预训练权重。
RoBERTa-wwm-ext 中文模型是基于 RoBERTa 用全词Mask方法预训练出的模型。

The RoBERTa-base-ch model uses the RoBERTa-wwm-ext pre-trained weights open sourced by the Harbin Institute of Technology Xunfei Lab (HFL).

[RoBERTa-wwm-ext](https://ieeexplore.ieee.org/document/9599397) 中文模型是基于RoBERTa使用全词Mask方法预训练出的模型

RoBERTa-wwm-ext chinese model is pre-trained based on the RoBERTa model using the whole word mask method. 
The pre-training method of [whole word mask](https://ieeexplore.ieee.org/document/9599397) is proposed by Yiming Cui Wanxiang Che Ting Liu Bing Qin Ziqing Yang.


## 训练数据/Training data

中文维基百科，其他百科、新闻、问答等数据，总词数达5.4B。

Chinese Wikipedia, other encyclopedias, news, q&A and other data, total words up to 5.4B.

## 使用方式/How to use

### 微调与推断/Finetune and inference

依托于[FlagAI](https://github.com/BAAI-Open/FlagAI)，用户可以使用RoBERTa模型完成[分类](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_11_BERT_EXAMPLE_SEMANTIC_MATCHING.md)，[序列分类](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_14_BERT_EXAMPLE_NER.md)和[序列生成任务](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_10_BERT_EXAMPLE_TITLE_GENERATION.md)

With [FlagAI](https://gitee.com/link?target=https%3A%2F%2Fgithub.com%2FBAAI-Open%2FFlagAI), One can use RoBERTa model to do [classification](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_11_BERT_EXAMPLE_SEMANTIC_MATCHING.md), [sequence labeling](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_14_BERT_EXAMPLE_NER.md) and [seq2seq tasks](https://github.com/BAAI-Open/FlagAI/blob/master/docs/TUTORIAL_10_BERT_EXAMPLE_TITLE_GENERATION.md).


### 快速使用/quick start

```
model = GLMModel.from_pretrain(model_name='RoBERTa-base-ch', download_path="./state_dict/")
tokenizer = GLMLargeChTokenizer(vocab_path='./state_dict/RoBERTa-base-ch/vocab.txt')
```


## 来源/Source
原代码可以点击此处[here](https://github.com/ymcui/Chinese-BERT-wwm).

The original code can be found [here](https://github.com/ymcui/Chinese-BERT-wwm).


